# بناء Exmity Browser من الجوال

1. ارفع هذا المشروع إلى مستودع GitHub جديد.
2. افتح تبويب Actions.
3. اختر "Build Exmity Browser APK".
4. اضغط "Run workflow".
5. انتظر حتى تنتهي المهمة بنجاح.
6. افتح نتيجة التشغيل وانزل إلى Artifacts.
7. حمّل Exmity-Browser-debug-apk.zip وفك ضغطه لتحصل على APK.

ملاحظة:
- هذا Workflow يبني نسخة Debug للتجربة على جهازك.
- للنشر على Google Play تحتاج لاحقًا نسخة Release موقعة بمفتاح خاص.
