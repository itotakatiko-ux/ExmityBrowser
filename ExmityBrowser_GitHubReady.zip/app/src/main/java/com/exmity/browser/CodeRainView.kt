package com.exmity.browser

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.random.Random

/**
 * Lightweight animated background that looks like lines of code / symbols
 * falling downward (a subtle "digital rain" effect) behind the home screen.
 *
 * Implementation notes (kept deliberately cheap on CPU/battery):
 * - A single ValueAnimator drives one invalidate() per frame; no extra
 *   threads, no bitmaps, no allocations inside onDraw.
 * - Each column keeps a small integer drop position instead of a full
 *   particle system.
 * - The animator is started in onAttachedToWindow and cancelled in
 *   onDetachedFromWindow so it never runs while the view is off-screen
 *   (e.g. while a real webpage/tab is showing instead of the home screen).
 */
class CodeRainView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val glyphs = "01{}<>/;#$%&ABCDEFexmity".toCharArray()
    private val columnWidth = 34f
    private var fontSize = 26f

    private lateinit var drops: FloatArray
    private lateinit var speeds: FloatArray
    private lateinit var charForColumn: CharArray

    private val paint = Paint().apply {
        color = Color.parseColor("#1FE0B080") // faint, non-distracting
        textSize = fontSize
        isAntiAlias = true
    }
    private val brightPaint = Paint().apply {
        color = Color.parseColor("#3300FF9C")
        textSize = fontSize
        isAntiAlias = true
    }

    private var animator: ValueAnimator? = null
    private var initialized = false

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val columns = (w / columnWidth).toInt().coerceAtLeast(1)
        drops = FloatArray(columns) { Random.nextInt(-40, 0).toFloat() }
        speeds = FloatArray(columns) { 0.15f + Random.nextFloat() * 0.35f }
        charForColumn = CharArray(columns) { glyphs[Random.nextInt(glyphs.size)] }
        initialized = true
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 16
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { advance() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    private fun advance() {
        if (!initialized) return
        val h = height.takeIf { it > 0 } ?: return
        for (i in drops.indices) {
            drops[i] += speeds[i]
            if (drops[i] * fontSize > h && Random.nextFloat() > 0.985f) {
                drops[i] = Random.nextInt(-20, 0).toFloat()
                charForColumn[i] = glyphs[Random.nextInt(glyphs.size)]
                speeds[i] = 0.15f + Random.nextFloat() * 0.35f
            }
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!initialized) return
        for (i in drops.indices) {
            val x = i * columnWidth
            val y = drops[i] * fontSize
            if (y < 0 || y > height) continue
            val p = if (i % 5 == 0) brightPaint else paint
            canvas.drawText(charForColumn[i].toString(), x, y, p)
        }
    }
}
