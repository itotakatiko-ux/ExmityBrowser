package com.exmity.browser

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class PageEntry(val id: Long, val title: String, val url: String, val timestamp: Long)

/**
 * Very small SQLite wrapper for history + bookmarks.
 * Kept dependency-free (no Room) to stay light on APK size and memory.
 */
class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context.applicationContext, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "exmity_browser.db"
        private const val DB_VERSION = 1

        private const val TABLE_HISTORY = "history"
        private const val TABLE_BOOKMARKS = "bookmarks"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE $TABLE_HISTORY (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "title TEXT, url TEXT, timestamp INTEGER)"
        )
        db.execSQL(
            "CREATE TABLE $TABLE_BOOKMARKS (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "title TEXT, url TEXT UNIQUE, timestamp INTEGER)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_HISTORY")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_BOOKMARKS")
        onCreate(db)
    }

    // ---------- History ----------

    fun addHistory(title: String, url: String) {
        val values = ContentValues().apply {
            put("title", title)
            put("url", url)
            put("timestamp", System.currentTimeMillis())
        }
        writableDatabase.insert(TABLE_HISTORY, null, values)
    }

    fun getHistory(): List<PageEntry> {
        val list = mutableListOf<PageEntry>()
        val cursor = readableDatabase.rawQuery(
            "SELECT id, title, url, timestamp FROM $TABLE_HISTORY ORDER BY timestamp DESC LIMIT 500", null
        )
        cursor.use {
            while (it.moveToNext()) {
                list.add(
                    PageEntry(
                        it.getLong(0), it.getString(1) ?: "", it.getString(2) ?: "", it.getLong(3)
                    )
                )
            }
        }
        return list
    }

    fun deleteHistoryEntry(id: Long) {
        writableDatabase.delete(TABLE_HISTORY, "id=?", arrayOf(id.toString()))
    }

    fun clearHistory() {
        writableDatabase.delete(TABLE_HISTORY, null, null)
    }

    // ---------- Bookmarks ----------

    fun addBookmark(title: String, url: String) {
        val values = ContentValues().apply {
            put("title", title)
            put("url", url)
            put("timestamp", System.currentTimeMillis())
        }
        writableDatabase.insertWithOnConflict(
            TABLE_BOOKMARKS, null, values, SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun removeBookmark(url: String) {
        writableDatabase.delete(TABLE_BOOKMARKS, "url=?", arrayOf(url))
    }

    fun isBookmarked(url: String): Boolean {
        val cursor = readableDatabase.rawQuery(
            "SELECT id FROM $TABLE_BOOKMARKS WHERE url=? LIMIT 1", arrayOf(url)
        )
        cursor.use { return it.moveToFirst() }
    }

    fun getBookmarks(): List<PageEntry> {
        val list = mutableListOf<PageEntry>()
        val cursor = readableDatabase.rawQuery(
            "SELECT id, title, url, timestamp FROM $TABLE_BOOKMARKS ORDER BY timestamp DESC", null
        )
        cursor.use {
            while (it.moveToNext()) {
                list.add(
                    PageEntry(
                        it.getLong(0), it.getString(1) ?: "", it.getString(2) ?: "", it.getLong(3)
                    )
                )
            }
        }
        return list
    }

    fun deleteBookmarkEntry(id: Long) {
        writableDatabase.delete(TABLE_BOOKMARKS, "id=?", arrayOf(id.toString()))
    }
}
