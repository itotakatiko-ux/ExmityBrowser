package com.exmity.browser

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TabsAdapter(
    private val tabs: List<BrowserTab>,
    private val onSelect: (Int) -> Unit,
    private val onClose: (Int) -> Unit
) : RecyclerView.Adapter<TabsAdapter.TabViewHolder>() {

    class TabViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.tabTitle)
        val url: TextView = view.findViewById(R.id.tabUrl)
        val privateIcon: ImageView = view.findViewById(R.id.tabPrivateIcon)
        val closeBtn: ImageButton = view.findViewById(R.id.btnCloseTab)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TabViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_tab, parent, false)
        return TabViewHolder(view)
    }

    override fun onBindViewHolder(holder: TabViewHolder, position: Int) {
        val tab = tabs[position]
        holder.title.text = tab.title.ifBlank { "تبويب جديد" }
        holder.url.text = tab.url ?: "الصفحة الرئيسية"
        holder.privateIcon.visibility = if (tab.isPrivate) View.VISIBLE else View.GONE
        holder.itemView.setOnClickListener { onSelect(position) }
        holder.closeBtn.setOnClickListener { onClose(position) }
    }

    override fun getItemCount(): Int = tabs.size
}
