package com.exmity.browser

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ExmityApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Load the ad-block host list once in the background so the very
        // first page load already benefits from it.
        CoroutineScope(Dispatchers.IO).launch {
            AdBlocker.load(applicationContext)
        }
    }
}
