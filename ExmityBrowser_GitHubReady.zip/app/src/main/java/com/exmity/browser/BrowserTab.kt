package com.exmity.browser

import android.webkit.WebView

/**
 * Represents a single browser tab.
 * Each tab owns its own WebView instance so tabs are fully independent
 * (separate back/forward history, separate loading state).
 */
data class BrowserTab(
    val id: Long,
    var webView: WebView?,
    var title: String = "تبويب جديد",
    var url: String? = null,          // null => showing the home screen
    val isPrivate: Boolean = false,
    var isLoading: Boolean = false
)
