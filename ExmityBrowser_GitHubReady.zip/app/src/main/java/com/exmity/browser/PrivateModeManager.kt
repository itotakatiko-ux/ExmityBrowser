package com.exmity.browser

import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView

/**
 * Private Mode in Exmity Browser means:
 *  - Pages visited in a private tab are never written to the local
 *    history database.
 *  - When the LAST private tab is closed, we proactively clear cookies
 *    and any local web storage that private browsing touched, and wipe
 *    each private WebView's own cache/history so nothing about that
 *    session lingers on the device.
 *
 * IMPORTANT / honest limitation (also shown to the user in Settings):
 * Android's WebView shares a single cookie store process-wide, so we
 * cannot perfectly sandbox a private tab from a normal tab the way a
 * separate browser profile would. We mitigate this by clearing cookies
 * as soon as private browsing ends. Private Mode does NOT hide the
 * device's IP address from websites or from the network/ISP - it only
 * affects what gets stored locally on this device.
 */
object PrivateModeManager {

    fun clearPrivateSessionData(webView: WebView?) {
        webView?.apply {
            clearHistory()
            clearCache(true)
            clearFormData()
        }
    }

    /** Call when the last private tab closes. */
    fun onAllPrivateTabsClosed() {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
    }
}
