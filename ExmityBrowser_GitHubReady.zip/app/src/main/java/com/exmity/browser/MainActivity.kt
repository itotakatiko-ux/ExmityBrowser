package com.exmity.browser

import android.app.AlertDialog
import androidx.activity.addCallback
import android.content.Intent
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.util.Patterns
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var addressBar: EditText
    private lateinit var securityIcon: ImageView
    private lateinit var loadingSpinner: ProgressBar
    private lateinit var insecureWarning: View
    private lateinit var homeScreen: View
    private lateinit var webViewContainer: FrameLayout
    private lateinit var btnBookmark: ImageButton
    private lateinit var btnTabs: ImageButton

    private lateinit var db: DatabaseHelper

    private val tabs = mutableListOf<BrowserTab>()
    private var currentTabIndex = -1
    private var nextTabId = 1L
    private var everOpenedPrivateTab = false

    private val prefs by lazy { SettingsActivity.prefs(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Apply saved night-mode preference before inflating views.
        val prefsEarly = SettingsActivity.prefs(this)
        AppCompatDelegate.setDefaultNightMode(
            if (prefsEarly.getBoolean("pref_night_mode", false))
                AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = DatabaseHelper(this)
        AdBlocker.load(this) // no-op if already loaded by ExmityApp

        addressBar = findViewById(R.id.addressBar)
        securityIcon = findViewById(R.id.securityIcon)
        loadingSpinner = findViewById(R.id.loadingSpinner)
        insecureWarning = findViewById(R.id.insecureWarning)
        homeScreen = findViewById(R.id.homeScreen)
        webViewContainer = findViewById(R.id.webViewContainer)
        btnBookmark = findViewById(R.id.btnBookmark)
        btnTabs = findViewById(R.id.btnTabs)

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { goBackInTab() }
        findViewById<ImageButton>(R.id.btnForward).setOnClickListener { goForwardInTab() }
        findViewById<ImageButton>(R.id.btnRefresh).setOnClickListener { currentWebView()?.reload() }
        findViewById<ImageButton>(R.id.btnHome).setOnClickListener { goHome() }
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        btnBookmark.setOnClickListener { toggleBookmarkForCurrentPage() }
        btnBookmark.setOnLongClickListener { showBookmarksDialog(); true }
        findViewById<ImageButton>(R.id.btnHistory).setOnClickListener { showHistoryDialog() }
        btnTabs.setOnClickListener { showTabsDialog() }

        onBackPressedDispatcher.addCallback(this) {
            val wv = currentWebView()
            when {
                wv != null && wv.canGoBack() -> wv.goBack()
                tabs.size > 1 -> closeTab(currentTabIndex)
                else -> {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        }

        addressBar.setOnEditorActionListener { _, actionId, event ->
            val isEnter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER
            if (actionId == EditorInfo.IME_ACTION_GO || isEnter) {
                loadUrlOrSearch(addressBar.text.toString())
                true
            } else false
        }

        // Handle links opened from other apps (VIEW intent).
        val incomingUrl = intent?.dataString
        createNewTab(url = incomingUrl, isPrivate = false)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.dataString?.let { createNewTab(url = it, isPrivate = false) }
    }

    // ---------------------------------------------------------------
    // Tab management
    // ---------------------------------------------------------------

    private fun buildWebView(isPrivate: Boolean): WebView {
        val webView = WebView(this)
        webView.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        )

        // We do not implement any credential-saving UI/consent flow, so we
        // deliberately keep Android Autofill from offering to save
        // passwords/sensitive form data through this WebView.
        webView.importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO

        val s: WebSettings = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = true // saves battery/data
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.cacheMode = if (isPrivate) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        s.textZoom = prefs.getInt("pref_font_size", 100)
        s.setSupportMultipleWindows(true)

        if (isPrivate) {
            // No persistent disk cache for private tabs.
            webView.clearCache(true)
        }

        webView.webViewClient = buildWebViewClient(isPrivate)
        webView.webChromeClient = buildWebChromeClient()
        return webView
    }

    private fun buildWebViewClient(isPrivate: Boolean) = object : WebViewClient() {

        override fun shouldInterceptRequest(
            view: WebView, request: WebResourceRequest
        ): WebResourceResponse? {
            val adBlockOn = prefs.getBoolean("pref_adblock_enabled", true)
            if (adBlockOn && AdBlocker.isAdUrl(request.url.toString())) {
                return AdBlocker.blockedResponse()
            }
            return super.shouldInterceptRequest(view, request)
        }

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val url = request.url.toString()
            // Let the WebView handle normal http/https navigation itself.
            if (url.startsWith("http://") || url.startsWith("https://")) return false
            // Refuse to silently hand off to arbitrary external schemes
            // (tel:, intent:, market:, etc.) without the user's action;
            // try to open a matching app, otherwise ignore.
            return try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                true
            } catch (_: Exception) {
                true
            }
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
            super.onPageStarted(view, url, favicon)
            val idx = indexOfWebView(view)
            if (idx == -1) return
            tabs[idx].isLoading = true
            tabs[idx].url = url
            if (idx == currentTabIndex) {
                addressBar.setText(url)
                updateSecurityUi(url)
                loadingSpinner.visibility = View.VISIBLE
            }
        }

        override fun onPageFinished(view: WebView, url: String?) {
            super.onPageFinished(view, url)
            val idx = indexOfWebView(view)
            if (idx == -1) return
            tabs[idx].isLoading = false
            tabs[idx].url = url
            val title = view.title ?: url ?: ""
            tabs[idx].title = title

            if (!isPrivate && !url.isNullOrBlank() && url.startsWith("http")) {
                db.addHistory(title, url)
            }
            if (idx == currentTabIndex) {
                loadingSpinner.visibility = View.GONE
                updateSecurityUi(url)
                updateBookmarkIcon(url)
            }
        }

        override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
            AlertDialog.Builder(this@MainActivity)
                .setTitle(R.string.ssl_error_title)
                .setMessage(R.string.ssl_error_message)
                .setPositiveButton(R.string.proceed_anyway) { _, _ -> handler.proceed() }
                .setNegativeButton(R.string.cancel) { _, _ -> handler.cancel() }
                .setCancelable(false)
                .show()
        }
    }

    private fun buildWebChromeClient() = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) {
            super.onProgressChanged(view, newProgress)
            val idx = indexOfWebView(view)
            if (idx == currentTabIndex) {
                loadingSpinner.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }

        override fun onReceivedTitle(view: WebView, title: String?) {
            super.onReceivedTitle(view, title)
            val idx = indexOfWebView(view)
            if (idx != -1 && !title.isNullOrBlank()) tabs[idx].title = title
        }

        override fun onCreateWindow(
            view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message
        ): Boolean {
            // target="_blank" links open in a new tab, like a normal browser.
            val newTab = createNewTab(url = null, isPrivate = tabs.getOrNull(currentTabIndex)?.isPrivate ?: false)
            val transport = resultMsg.obj as WebView.WebViewTransport
            transport.webView = newTab.webView
            resultMsg.sendToTarget()
            return true
        }
    }

    private fun indexOfWebView(webView: WebView): Int = tabs.indexOfFirst { it.webView === webView }

    private fun createNewTab(url: String?, isPrivate: Boolean): BrowserTab {
        val webView = buildWebView(isPrivate)
        webViewContainer.addView(webView)
        webView.visibility = View.GONE
        val tab = BrowserTab(id = nextTabId++, webView = webView, url = url, isPrivate = isPrivate)
        tabs.add(tab)
        if (isPrivate) everOpenedPrivateTab = true

        switchToTab(tabs.size - 1)
        if (!url.isNullOrBlank()) {
            loadUrlOrSearch(url)
        } else {
            showHomeScreen()
        }
        return tab
    }

    private fun switchToTab(index: Int) {
        if (index !in tabs.indices) return
        tabs.getOrNull(currentTabIndex)?.webView?.visibility = View.GONE
        currentTabIndex = index
        val tab = tabs[index]
        tab.webView?.visibility = View.VISIBLE
        addressBar.setText(tab.url ?: "")
        updateSecurityUi(tab.url)
        updateBookmarkIcon(tab.url)
        if (tab.url.isNullOrBlank()) showHomeScreen() else showWebScreen()
        updateTabsBadge()
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs[index]
        webViewContainer.removeView(tab.webView)
        tab.webView?.stopLoading()
        tab.webView?.destroy()
        tabs.removeAt(index)

        if (tab.isPrivate && tabs.none { it.isPrivate }) {
            PrivateModeManager.onAllPrivateTabsClosed()
        }

        if (tabs.isEmpty()) {
            createNewTab(url = null, isPrivate = false)
            return
        }

        val newIndex = (index - 1).coerceIn(0, tabs.size - 1)
        switchToTab(newIndex)
    }

    private fun updateTabsBadge() {
        // The tabs button itself just opens the switcher; the live count is
        // shown inside the tabs dialog title. Kept simple/cheap here.
    }

    // ---------------------------------------------------------------
    // Navigation helpers
    // ---------------------------------------------------------------

    private fun currentWebView(): WebView? = tabs.getOrNull(currentTabIndex)?.webView

    private fun goBackInTab() {
        val wv = currentWebView()
        if (wv != null && wv.canGoBack()) wv.goBack()
    }

    private fun goForwardInTab() {
        val wv = currentWebView()
        if (wv != null && wv.canGoForward()) wv.goForward()
    }

    private fun goHome() {
        val homepage = prefs.getString("pref_homepage_url", "exmity://home") ?: "exmity://home"
        if (homepage == "exmity://home" || homepage.isBlank()) {
            tabs.getOrNull(currentTabIndex)?.url = null
            addressBar.setText("")
            showHomeScreen()
        } else {
            loadUrlOrSearch(homepage)
        }
    }

    private fun showHomeScreen() {
        homeScreen.visibility = View.VISIBLE
        webViewContainer.visibility = View.GONE
    }

    private fun showWebScreen() {
        homeScreen.visibility = View.GONE
        webViewContainer.visibility = View.VISIBLE
    }

    private fun loadUrlOrSearch(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return

        val finalUrl = when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            Patterns.WEB_URL.matcher(trimmed).matches() && !trimmed.contains(" ") -> "https://$trimmed"
            else -> {
                val template = prefs.getString(
                    "pref_search_engine", "https://www.google.com/search?q=%s"
                ) ?: "https://www.google.com/search?q=%s"
                template.replace("%s", Uri.encode(trimmed))
            }
        }

        var wv = currentWebView()
        if (wv == null) {
            createNewTab(url = finalUrl, isPrivate = false)
            return
        }
        showWebScreen()
        tabs.getOrNull(currentTabIndex)?.url = finalUrl
        wv.loadUrl(finalUrl)
    }

    private fun updateSecurityUi(url: String?) {
        if (url == null || !url.startsWith("http")) {
            securityIcon.visibility = View.GONE
            insecureWarning.visibility = View.GONE
            return
        }
        securityIcon.visibility = View.VISIBLE
        if (url.startsWith("https://")) {
            securityIcon.setImageResource(R.drawable.ic_lock)
            insecureWarning.visibility = View.GONE
        } else {
            securityIcon.setImageResource(R.drawable.ic_warning)
            insecureWarning.visibility = View.VISIBLE
        }
    }

    // ---------------------------------------------------------------
    // Bookmarks
    // ---------------------------------------------------------------

    private fun toggleBookmarkForCurrentPage() {
        val tab = tabs.getOrNull(currentTabIndex) ?: return
        val url = tab.url ?: return
        if (db.isBookmarked(url)) {
            db.removeBookmark(url)
            Toast.makeText(this, R.string.removed_from_bookmarks, Toast.LENGTH_SHORT).show()
        } else {
            db.addBookmark(tab.title, url)
            Toast.makeText(this, R.string.added_to_bookmarks, Toast.LENGTH_SHORT).show()
        }
        updateBookmarkIcon(url)
    }

    private fun updateBookmarkIcon(url: String?) {
        val bookmarked = url != null && db.isBookmarked(url)
        btnBookmark.setImageResource(if (bookmarked) R.drawable.ic_star else R.drawable.ic_star_border)
    }

    // ---------------------------------------------------------------
    // Dialogs: tabs / history / bookmarks
    // ---------------------------------------------------------------

    private fun showTabsDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_tabs, null)
        val dialog = AlertDialog.Builder(this).setView(view).create()

        val title = view.findViewById<TextView>(R.id.tabsTitle)
        title.text = getString(R.string.tabs) + " (${tabs.size})"

        val recycler = view.findViewById<RecyclerView>(R.id.tabsRecyclerView)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = TabsAdapter(
            tabs,
            onSelect = { index -> switchToTab(index); dialog.dismiss() },
            onClose = { index ->
                closeTab(index)
                title.text = getString(R.string.tabs) + " (${tabs.size})"
                recycler.adapter?.notifyDataSetChanged()
            }
        )

        view.findViewById<ImageButton>(R.id.btnNewTab).setOnClickListener {
            createNewTab(url = null, isPrivate = false)
            dialog.dismiss()
        }
        view.findViewById<ImageButton>(R.id.btnNewPrivateTab).setOnClickListener {
            createNewTab(url = null, isPrivate = true)
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showHistoryDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_list, null)
        val dialog = AlertDialog.Builder(this).setView(view).create()
        view.findViewById<TextView>(R.id.listTitle).text = getString(R.string.history)

        val items = db.getHistory().toMutableList()
        val empty = view.findViewById<TextView>(R.id.emptyText)
        empty.text = getString(R.string.no_history)
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE

        val recycler = view.findViewById<RecyclerView>(R.id.listRecyclerView)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = PageListAdapter(
            items,
            onClick = { entry -> loadUrlOrSearch(entry.url); dialog.dismiss() },
            onDelete = { entry, _ -> db.deleteHistoryEntry(entry.id) }
        )
        dialog.show()
    }

    private fun showBookmarksDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_list, null)
        val dialog = AlertDialog.Builder(this).setView(view).create()
        view.findViewById<TextView>(R.id.listTitle).text = getString(R.string.bookmarks)

        val items = db.getBookmarks().toMutableList()
        val empty = view.findViewById<TextView>(R.id.emptyText)
        empty.text = getString(R.string.no_bookmarks)
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE

        val recycler = view.findViewById<RecyclerView>(R.id.listRecyclerView)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = PageListAdapter(
            items,
            onClick = { entry -> loadUrlOrSearch(entry.url); dialog.dismiss() },
            onDelete = { entry, _ -> db.deleteBookmarkEntry(entry.id) }
        )
        dialog.show()
    }

    // ---------------------------------------------------------------
    // Lifecycle / back button
    // ---------------------------------------------------------------

    override fun onDestroy() {
        if (everOpenedPrivateTab) {
            PrivateModeManager.onAllPrivateTabsClosed()
        }
        tabs.forEach { it.webView?.destroy() }
        super.onDestroy()
    }
}
