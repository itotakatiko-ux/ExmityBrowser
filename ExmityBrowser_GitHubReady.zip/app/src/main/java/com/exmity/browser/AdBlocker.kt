package com.exmity.browser

import android.content.Context
import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.File

/**
 * A real, host-based ad/tracker blocker.
 *
 * How it works:
 * - We ship a "hosts" style blocklist under assets/adblock_hosts.txt
 *   (same format used by well-known public blocklists such as StevenBlack's
 *   hosts project: "0.0.0.0 tracker.example.com" per line).
 * - On every network sub-request the WebView makes (images, scripts, XHR,
 *   iframes, etc.) we check the request's host against the list. If it
 *   matches, we hand back an empty response instead of letting the request
 *   reach the network, which is the standard technique used by hosts-file
 *   based ad blockers.
 * - This blocks known ad/tracking domains only. It never touches login
 *   forms, paywalls, or any site's own authentication/session logic - it
 *   simply refuses to fetch resources from domains on the list.
 *
 * The list can be updated any time: see README section "6. تحديث AdBlock".
 */
object AdBlocker {

    private val blockedExactHosts = HashSet<String>()
    private var loaded = false
    private val lock = Any()

    private val emptyResponse: WebResourceResponse
        get() = WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    /** Loads the bundled list, plus any user-added custom list, into memory. */
    fun load(context: Context) {
        synchronized(lock) {
            if (loaded) return
            try {
                context.assets.open("adblock_hosts.txt").bufferedReader().useLines { lines ->
                    lines.forEach { parseLine(it) }
                }
            } catch (_: Exception) {
                // If the bundled list is somehow missing, blocking is simply
                // disabled rather than crashing the browser.
            }
            // Optional user-editable custom list stored in internal storage,
            // e.g. added by an advanced user via adb push (see README).
            try {
                val customFile = File(context.filesDir, "custom_adblock_hosts.txt")
                if (customFile.exists()) {
                    customFile.bufferedReader().useLines { lines -> lines.forEach { parseLine(it) } }
                }
            } catch (_: Exception) {
            }
            loaded = true
        }
    }

    private fun parseLine(rawLine: String) {
        val line = rawLine.trim()
        if (line.isEmpty() || line.startsWith("#") || line.startsWith("!")) return
        val parts = line.split(Regex("\\s+"))
        val host = if (parts.size >= 2) parts[1] else parts[0]
        val normalized = host.trim().lowercase()
        if (normalized.isEmpty() || normalized == "0.0.0.0" || normalized == "localhost") return
        blockedExactHosts.add(normalized)
    }

    /** True if the given request URL's host is a known ad/tracking domain. */
    fun isAdUrl(url: String): Boolean {
        if (!loaded) return false
        val host = try {
            Uri.parse(url).host?.lowercase()
        } catch (_: Exception) {
            null
        } ?: return false

        if (blockedExactHosts.contains(host)) return true

        // Also match subdomains of a blocked domain, e.g. "ads.example.com"
        // is blocked if "example.com" (or any parent) is on the list.
        var current = host
        while (current.contains('.')) {
            current = current.substringAfter('.')
            if (blockedExactHosts.contains(current)) return true
        }
        return false
    }

    fun blockedResponse(): WebResourceResponse = emptyResponse

    fun blockedHostCount(): Int = blockedExactHosts.size
}
