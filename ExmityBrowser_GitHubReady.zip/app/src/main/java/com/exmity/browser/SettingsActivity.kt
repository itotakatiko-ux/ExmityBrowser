package com.exmity.browser

import android.content.Context
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.PreferenceManager

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        setSupportActionBar(findViewById(R.id.settingsToolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        supportFragmentManager.beginTransaction()
            .replace(R.id.settingsContainer, SettingsFragment())
            .commit()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    class SettingsFragment : PreferenceFragmentCompat() {

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)

            findPreference<Preference>("pref_night_mode")?.setOnPreferenceChangeListener { _, newValue ->
                val enabled = newValue as Boolean
                AppCompatDelegate.setDefaultNightMode(
                    if (enabled) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
                )
                true
            }

            findPreference<Preference>("pref_clear_history")?.setOnPreferenceClickListener {
                DatabaseHelper(requireContext()).clearHistory()
                toast(getString(R.string.cleared_done))
                true
            }

            findPreference<Preference>("pref_clear_site_data")?.setOnPreferenceClickListener {
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                WebStorage.getInstance().deleteAllData()
                toast(getString(R.string.cleared_done))
                true
            }

            findPreference<Preference>("pref_clear_cache")?.setOnPreferenceClickListener {
                // WebView cache lives per-instance; clearing the app's own
                // cache directory covers everything the browser itself wrote.
                requireContext().cacheDir.deleteRecursively()
                toast(getString(R.string.cleared_done))
                true
            }
        }

        private fun toast(msg: String) {
            Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        fun prefs(context: Context) = PreferenceManager.getDefaultSharedPreferences(context)
    }
}
