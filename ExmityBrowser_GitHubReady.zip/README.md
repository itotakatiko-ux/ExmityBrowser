# Exmity Browser

متصفح ويب حقيقي لنظام Android، مبني بلغة **Kotlin** ومحرك **Android WebView (Chromium)**، وليس موقع ويب يحاكي متصفحًا. المشروع جاهز لفتحه في Android Studio والبناء منه مباشرة.

---

## 1) لغة البرمجة المستخدمة

- **Kotlin 100%** لكل منطق التطبيق (Activities، محرك التبويبات، AdBlocker، قاعدة البيانات...).
- محرك عرض الصفحات هو **`android.webkit.WebView`**، وهو الطبقة الرسمية في Android التي تستخدم محرك **Chromium** المثبّت على الجهاز (عبر تطبيق/مكوّن "Android System WebView" أو Chrome) — هذا هو نفس الأسلوب الذي تُبنى به معظم المتصفحات البديلة الخفيفة على أندرويد.
- XML لملفات الواجهات (layouts) والموارد (strings/colors/themes)، و Gradle Kotlin DSL (`.kts`) لملفات البناء.

## 2) طريقة تشغيل المشروع

1. ثبّت **Android Studio** (إصدار Koala أو أحدث يُفضّل).
2. افتح Android Studio → `Open` → اختر مجلد `ExmityBrowser` بالكامل (المجلد الذي يحتوي `settings.gradle.kts`).
3. انتظر حتى ينتهي **Gradle Sync** تلقائيًا (سيقوم بتنزيل التبعيات المطلوبة فقط: AndroidX الأساسية + Material + Preference + RecyclerView + Coroutines — لا مكتبات ضخمة).
4. وصّل جهاز أندرويد حقيقي (بوضع "تصحيح USB" مفعّل) أو شغّل **AVD Emulator** (API 24 فأعلى).
5. اضغط زر **Run ▶** في Android Studio.

> ملاحظة: بيئة العمل الحالية التي أنشأت لك هذا المشروع لا تحتوي على Android SDK لتصدر APK مباشرة من هنا، لذلك عليك بناءه من جهازك عبر Android Studio كما هو موضح.

## 3) طريقة بناء APK

**الطريقة الأسهل (عبر الواجهة):**
`Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
سيظهر إشعار بمكان الملف الناتج، عادة:
`app/build/outputs/apk/debug/app-debug.apk`

**لنسخة موقّعة جاهزة للنشر (Release):**
`Build` → `Generate Signed Bundle / APK` → اختر `APK` → أنشئ أو اختر Keystore → أكمل التوقيع.
الناتج: `app/build/outputs/apk/release/app-release.apk`

**عبر سطر الأوامر (اختياري):**
```bash
./gradlew assembleDebug
# أو نسخة موقعة للنشر:
./gradlew assembleRelease
```
(في أول تشغيل، Android Studio ينشئ لك ملفات `gradlew` / `gradlew.bat` تلقائيًا إن لم تكن موجودة — أو يمكنك تفعيل "Gradle Wrapper" من `File > Sync Project with Gradle Files`.)

## 4) أين أضع شعار التطبيق

يوجد مكانان للشعار:

**أ) أيقونة التطبيق (Launcher Icon)** التي تظهر في قائمة تطبيقات الجهاز:
- الشكل الافتراضي الحالي بسيط (دائرة + خط منحنٍ بلون العلامة التجارية) في:
  - `app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml` (للأجهزة الحديثة، Adaptive Icon)
  - `app/src/main/res/drawable/ic_launcher_foreground.xml` (الشكل الأمامي)
  - `app/src/main/res/mipmap-hdpi|xhdpi|xxhdpi/ic_launcher.png` (نسخ احتياطية للأجهزة الأقدم)
- **لاستبدالها بشعارك الخاص:** أسهل طريقة هي كليك يمين على `app` في Android Studio → `New` → `Image Asset` → اختر صورة الشعار (PNG مربّع بخلفية شفافة يُفضّل)، وسيولّد لك كل الأحجام المطلوبة تلقائيًا ويستبدل الملفات القديمة.

**ب) شعار الصفحة الرئيسية (Home Screen) داخل التطبيق:**
- حاليًا هو دائرة متدرّجة اللون تحمل حرف "E" في:
  `app/src/main/res/layout/activity_main.xml` داخل العنصر `homeScreen`.
- لاستبداله بصورة شعارك: أضف ملف الصورة (مثلاً `logo.png`) داخل `app/src/main/res/drawable/`، ثم استبدل الـ `FrameLayout` الذي يحتوي حرف "E" بعنصر:
  ```xml
  <ImageView
      android:layout_width="88dp"
      android:layout_height="88dp"
      android:src="@drawable/logo" />
  ```

## 5) كيف أضيف أو أغيّر قوائم AdBlock

قائمة الحجب الحالية موجودة في:
`app/src/main/assets/adblock_hosts.txt`

- الصيغة المدعومة هي نفس صيغة قوائم Hosts الشهيرة والموثوقة (مثل مشروع StevenBlack/hosts):
  ```
  0.0.0.0 domain-to-block.com
  ```
  أو حتى مجرد اسم النطاق وحده في السطر.
- **لتحديثها بقائمة أشمل:** حمّل أي قائمة Hosts محدّثة من مصدر موثوق (مثل مستودع StevenBlack على GitHub)، وضع محتواها في نفس الملف (أو استبدله بالكامل) قبل بناء التطبيق.
- **لإضافة نطاقات مخصّصة بدون إعادة بناء التطبيق:** يدعم الكود أيضًا ملفًا اختياريًا يُقرأ من تخزين التطبيق الداخلي:
  `/data/data/com.exmity.browser/files/custom_adblock_hosts.txt`
  يمكن دفعه عبر ADB أثناء التطوير:
  ```bash
  adb push my_extra_list.txt /data/data/com.exmity.browser/files/custom_adblock_hosts.txt
  ```
- منطق الحجب نفسه موجود في:
  `app/src/main/java/com/exmity/browser/AdBlocker.kt`
  وهو يعمل عبر اعتراض كل طلب فرعي (صور/سكربتات/iframes) في `shouldInterceptRequest` ومطابقة اسم النطاق (Host) — وليس عبر تجاوز أي حماية أو تسجيل دخول للمواقع، تمامًا كما طلبت.
- يمكن تفعيله/إيقافه من `الإعدادات ⚙️ → تفعيل مانع الإعلانات`.

## 6) كيف أختبر Private Mode

1. من زر **التبويبات 🗂️** في الأعلى، اضغط أيقونة **التبويب الخاص** (🕶️) بجانب زر "+".
2. تصفّح أي موقع داخل هذا التبويب، ثم أغلقه (زر ✕ على التبويب).
3. تحقّق أن الصفحة **لم تُضف** إلى `سجل التصفح 🕘` (من الشريط السفلي).
4. عند إغلاق التطبيق بالكامل بعد استخدام تبويب خاص، يقوم التطبيق تلقائيًا بحذف الكوكيز وبيانات التخزين المحلية للجلسة (`PrivateModeManager.kt`).
5. يمكنك أيضًا اختبار المسح اليدوي من `الإعدادات → مسح السجل / مسح بيانات المواقع / مسح الكاش`.

**تنويه مهم (موجود أيضًا داخل شاشة الإعدادات):**
وضع الخصوصية في Exmity Browser **لا يجعلك مجهولًا بالكامل** على الإنترنت. هو يمنع فقط حفظ السجل والكوكيز وبيانات الجلسة *محليًا على جهازك*. عنوان الـ IP الخاص بك يظل ظاهرًا للمواقع التي تزورها ولمزوّد خدمة الإنترنت، تمامًا كما هو الحال في وضع التصفح الخاص بأي متصفح آخر (Chrome/Firefox...). لإخفاء IP فعليًا تحتاج تقنيات إضافية مثل VPN، وهذا خارج نطاق هذا المشروع.

## 7) الخلفية المتحركة (أكواد متساقطة) في الصفحة الرئيسية

منفّذة في ملف مخصّص خفيف الأداء:
`app/src/main/java/com/exmity/browser/CodeRainView.kt`

- عبارة عن `View` مخصّصة (Custom View) ترسم أعمدة من رموز/أحرف تتحرك للأسفل بأسلوب "المطر الرقمي" (شبيه بخلفيات الأفلام التقنية)، بشفافية منخفضة حتى لا تُشتّت الانتباه عن الشعار والنص.
- تعمل فقط عندما تكون الصفحة الرئيسية ظاهرة (تتوقف تلقائيًا عند فتح موقع حقيقي داخل تبويب، توفيرًا للبطارية والمعالج) عبر `onAttachedToWindow` / `onDetachedFromWindow`.
- لا تستخدم أي مكتبة خارجية أو صورًا/GIF — فقط `Canvas` و `ValueAnimator`، لذلك استهلاكها للذاكرة والمعالج منخفض جدًا.
- لتخصيصها: غيّر متغيّرات `glyphs` (الرموز المعروضة)، `columnWidth`، `fontSize`، أو الألوان داخل نفس الملف.

---

## ملخص المزايا المنفّذة

| الميزة | الحالة | الملف الرئيسي |
|---|---|---|
| فتح مواقع حقيقية عبر WebView | ✅ | `MainActivity.kt` |
| شريط عنوان/بحث ذكي (رابط أو بحث Google) | ✅ | `MainActivity.kt` (`loadUrlOrSearch`) |
| أزرار رجوع/تقدم/تحديث/رئيسية | ✅ | `activity_main.xml` + `MainActivity.kt` |
| تبويبات متعددة + زر "+" + إغلاق + عدّاد | ✅ | `TabsAdapter.kt`, `dialog_tabs.xml` |
| مانع إعلانات حقيقي (Host-based) قابل للتحديث | ✅ | `AdBlocker.kt`, `assets/adblock_hosts.txt` |
| تفعيل/إيقاف مانع الإعلانات من الإعدادات | ✅ | `preferences.xml` |
| وضع خصوصية (تبويب خاص) بدون حفظ سجل | ✅ | `PrivateModeManager.kt` |
| مسح السجل / الكوكيز / بيانات المواقع / الكاش | ✅ | `SettingsActivity.kt` |
| محرك بحث افتراضي قابل للاختيار | ✅ | `arrays.xml`, `preferences.xml` |
| وضع ليلي 🌙 | ✅ | `SettingsFragment` + `values-night/themes.xml` |
| حجم الخط | ✅ | `pref_font_size` → `WebSettings.textZoom` |
| صفحة رئيسية قابلة للتخصيص | ✅ | `pref_homepage_url` |
| تحذير HTTP غير آمن + شهادات SSL غير موثوقة | ✅ | `MainActivity.kt` (`updateSecurityUi`, `onReceivedSslError`) |
| عدم حفظ كلمات المرور تلقائيًا | ✅ | `importantForAutofill = IMPORTANT_FOR_AUTOFILL_NO` |
| صلاحيات Android الدنيا فقط (إنترنت) | ✅ | `AndroidManifest.xml` |
| خلفية "أكواد متساقطة" متحركة في الصفحة الرئيسية | ✅ | `CodeRainView.kt` |

## بنية المشروع

```
ExmityBrowser/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/adblock_hosts.txt
        ├── java/com/exmity/browser/
        │   ├── ExmityApp.kt
        │   ├── MainActivity.kt
        │   ├── SettingsActivity.kt
        │   ├── BrowserTab.kt
        │   ├── AdBlocker.kt
        │   ├── PrivateModeManager.kt
        │   ├── DatabaseHelper.kt
        │   ├── TabsAdapter.kt
        │   ├── PageListAdapter.kt
        │   └── CodeRainView.kt
        └── res/
            ├── layout/  (activity_main, activity_settings, dialog_tabs, dialog_list, item_tab, item_list_row)
            ├── drawable/ (أيقونات أصلية بسيطة + الشعار)
            ├── mipmap-*/ (أيقونة التطبيق)
            ├── values(-night)/ (ألوان، نصوص، ثيمات)
            └── xml/ (preferences.xml, network_security_config.xml)
```

## ملاحظات أداء وأمان إضافية

- لا توجد مكتبات ثقيلة: فقط AndroidX الأساسية + Material + Preference + RecyclerView + Coroutines (خفيفة جدًا).
- كل تبويب يملك `WebView` خاصًا به، ويُدمَّر (`destroy()`) فور إغلاق التبويب لتحرير الذاكرة فورًا.
- `mediaPlaybackRequiresUserGesture = true` لتفادي تشغيل فيديوهات/صوتيات تلقائيًا تستهلك البطارية والبيانات.
- `allowFileAccess = false` و `allowContentAccess = false` لتقليل مساحة الهجوم الأمنية.
- لا صلاحيات غير ضرورية في الـ Manifest: فقط `INTERNET` و `ACCESS_NETWORK_STATE`.

## الخطوة التالية المقترحة

هذه نسخة أولى متكاملة وتعمل. الإضافات المنطقية التالية (يمكن طلبها لاحقًا): إدارة كلمات مرور مع موافقة صريحة، مزامنة سحابية اختيارية للمفضلة، وضع القراءة (Reader Mode)، تنزيل الملفات، ودعم إيماءات السحب بين التبويبات.
